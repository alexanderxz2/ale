
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alexanderxz2',
  applicationName: 'retosoft',
  appUid: 'mk9XjB8mbQ5Mv9wFkk',
  orgUid: '4d7aa215-13d9-46a4-b009-c6ff3ef59887',
  deploymentUid: '7f1d8809-4c97-4fcc-b9bc-ebce368c96c7',
  serviceName: 'retosoft',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'retosoft-dev-api', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}